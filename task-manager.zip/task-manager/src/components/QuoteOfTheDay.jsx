import { useEffect, useState } from "react";

export default function QuoteOfTheDay() {
  const [quote, setQuote] = useState(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  const load = async (signal) => {
    setLoading(true);
    setErr("");
    try {
      const res = await fetch("https://api.quotable.io/random", { signal });
      if (!res.ok) throw new Error("Nie udało się pobrać cytatu.");
      const data = await res.json();
      setQuote({ content: data.content, author: data.author });
    } catch (e) {
      if (e?.name !== "AbortError") setErr(e?.message || "Błąd pobierania.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const controller = new AbortController();
    load(controller.signal);
    return () => controller.abort();
  }, []);

  return (
    <div style={{ padding: 12, borderRadius: 12, background: "rgba(255,255,255,0.7)", border: "1px solid rgba(0,0,0,0.08)" }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
        <strong>Cytat dnia</strong>
        <button type="button" onClick={() => load()}>Nowy cytat</button>
      </div>

      {loading ? (
        <p style={{ marginBottom: 0 }}>Ładowanie…</p>
      ) : err ? (
        <div>
          <p style={{ marginBottom: 8 }}>⚠️ {err}</p>
          <button type="button" onClick={() => load()}>Spróbuj ponownie</button>
        </div>
      ) : quote ? (
        <p style={{ marginBottom: 0 }}>„{quote.content}” — <em>{quote.author}</em></p>
      ) : null}
    </div>
  );
}
