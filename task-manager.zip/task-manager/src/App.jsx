import { useEffect, useMemo, useState } from "react";
import Header from "./components/Header";
import Card from "./components/Card";
import TaskForm from "./components/TaskForm";
import TaskList from "./components/TaskList";
import FilterButtons from "./components/FilterButtons";
import TaskStats from "./components/TaskStats";
import { clearAllTasks, fetchTasks, saveTasks } from "./api/tasksApi";

const PRIORITY_WEIGHT = { high: 3, medium: 2, low: 1 };

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [filter, setFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("ALL");
  const [query, setQuery] = useState("");
  const [sortMode, setSortMode] = useState("default");

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [loadErr, setLoadErr] = useState("");

  useEffect(() => {
    const controller = new AbortController();
    (async () => {
      setLoading(true);
      setLoadErr("");
      try {
        const loaded = await fetchTasks({ signal: controller.signal });
        setTasks(Array.isArray(loaded) ? loaded : []);
      } catch (e) {
        if (e?.name !== "AbortError") setLoadErr("Nie udało się wczytać zadań.");
      } finally {
        setLoading(false);
      }
    })();
    return () => controller.abort();
  }, []);

  useEffect(() => {
    if (loading) return;
    const controller = new AbortController();
    (async () => {
      setSaving(true);
      try {
        await saveTasks(tasks, { signal: controller.signal });
      } finally {
        setSaving(false);
      }
    })();
    return () => controller.abort();
  }, [tasks, loading]);

  const addTask = (task) => setTasks((prev) => [task, ...prev]);

  const toggleTask = (id) =>
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)));

  const deleteTask = (id) => setTasks((prev) => prev.filter((t) => t.id !== id));

  const changePriority = (id, newPriority) =>
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, priority: newPriority } : t)));

  const updateTask = (id, newTitle) =>
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, title: newTitle } : t)));

  const clearAll = () => {
    const ok = confirm("Na pewno wyczyścić wszystkie zadania?");
    if (!ok) return;
    clearAllTasks();
    setTasks([]);
  };

  const categories = useMemo(() => {
    const set = new Set(tasks.map((t) => t.category || "Inne"));
    return ["ALL", ...Array.from(set)];
  }, [tasks]);

  const filteredAndSorted = useMemo(() => {
    let list = [...tasks];

    if (filter === "active") list = list.filter((t) => !t.completed);
    if (filter === "completed") list = list.filter((t) => t.completed);

    if (categoryFilter !== "ALL") {
      list = list.filter((t) => (t.category || "Inne") === categoryFilter);
    }

    const q = query.trim().toLowerCase();
    if (q) list = list.filter((t) => (t.title || "").toLowerCase().includes(q));

    if (sortMode === "priority") {
      list.sort((a, b) => (PRIORITY_WEIGHT[b.priority] ?? 2) - (PRIORITY_WEIGHT[a.priority] ?? 2));
    } else if (sortMode === "alpha") {
      list.sort((a, b) => (a.title || "").localeCompare(b.title || "", "pl"));
    }

    return list;
  }, [tasks, filter, categoryFilter, query, sortMode]);

  const noResults =
    filteredAndSorted.length === 0 &&
    tasks.length > 0 &&
    (query.trim() || filter !== "all" || categoryFilter !== "ALL");

  return (
    <div style={{ minHeight: "100vh", padding: 18, background: "linear-gradient(180deg, #f6f7ff, #f3fbf7)" }}>
      <div style={{ maxWidth: 980, margin: "0 auto", display: "grid", gap: 14 }}>
        <Header />

        <Card>
          <div style={{ display: "grid", gap: 12 }}>
            <TaskForm onAdd={addTask} />

            <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
              <FilterButtons filter={filter} onChange={setFilter} />

              <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
                <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c === "ALL" ? "Wszystkie kategorie" : c}
                    </option>
                  ))}
                </select>

                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Szukaj…"
                  style={{ padding: 10, borderRadius: 10, border: "1px solid rgba(0,0,0,0.2)" }}
                />

                <select value={sortMode} onChange={(e) => setSortMode(e.target.value)}>
                  <option value="default">Domyślnie</option>
                  <option value="priority">Priorytet</option>
                  <option value="alpha">Alfabetycznie</option>
                </select>

                <button type="button" onClick={clearAll}>Wyczyść wszystko</button>
              </div>
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
              <TaskStats tasks={tasks} />
              <div style={{ opacity: 0.75 }}>
                {loading ? "Ładowanie…" : saving ? "Zapisywanie…" : " "}
              </div>
            </div>
          </div>
        </Card>

        <Card title="Lista zadań">
          {loadErr ? (
            <p style={{ margin: 0 }}>⚠️ {loadErr}</p>
          ) : loading ? (
            <p style={{ margin: 0 }}>Ładowanie…</p>
          ) : noResults ? (
            <p style={{ margin: 0 }}>Nie znaleziono zadań dla frazy «{query.trim()}».</p>
          ) : (
            <TaskList
              tasks={filteredAndSorted}
              onToggle={toggleTask}
              onDelete={deleteTask}
              onPriorityChange={changePriority}
              onUpdateTitle={updateTask}
            />
          )}
        </Card>
      </div>
    </div>
  );
}
