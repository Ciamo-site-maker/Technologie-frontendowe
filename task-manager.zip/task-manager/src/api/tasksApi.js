const delay = (ms, signal) =>
  new Promise((resolve, reject) => {
    const id = setTimeout(resolve, ms);
    if (signal) {
      signal.addEventListener("abort", () => {
        clearTimeout(id);
        reject(new DOMException("Aborted", "AbortError"));
      });
    }
  });

const LS_KEY = "task_manager_tasks_v1";

export async function fetchTasks({ signal } = {}) {
  await delay(600, signal);
  const raw = localStorage.getItem(LS_KEY);
  if (!raw) return [];
  return JSON.parse(raw);
}

export async function saveTasks(tasks, { signal } = {}) {
  await delay(500, signal);
  localStorage.setItem(LS_KEY, JSON.stringify(tasks));
  return true;
}

export function clearAllTasks() {
  localStorage.removeItem(LS_KEY);
}
