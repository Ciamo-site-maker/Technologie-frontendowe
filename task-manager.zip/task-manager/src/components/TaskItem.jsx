import { useEffect, useMemo, useState } from "react";

const categoryColors = {
  Praca: "rgba(0, 120, 255, 0.15)",
  Dom: "rgba(0, 180, 90, 0.15)",
  Zakupy: "rgba(255, 170, 0, 0.18)",
  Inne: "rgba(140, 120, 255, 0.16)",
};

export default function TaskItem({
  id,
  title,
  completed = false,
  priority = "medium",
  category = "Inne",
  onToggle,
  onDelete,
  onPriorityChange,
  onUpdateTitle,
}) {
  const [isEditing, setIsEditing] = useState(false);
  const [draft, setDraft] = useState(title);

  useEffect(() => setDraft(title), [title]);

  const prLabel = useMemo(() => {
    if (priority === "high") return "Wysoki";
    if (priority === "low") return "Niski";
    return "Średni";
  }, [priority]);

  const save = () => {
    const newTitle = draft.trim();
    if (newTitle.length < 3 || newTitle.length > 100) return;
    onUpdateTitle?.(id, newTitle);
    setIsEditing(false);
  };

  const cancel = () => {
    setDraft(title);
    setIsEditing(false);
  };

  return (
    <li style={{
      display: "grid",
      gridTemplateColumns: "auto 1fr auto",
      gap: 10,
      padding: 12,
      borderRadius: 14,
      border: "1px solid rgba(0,0,0,0.08)",
      background: "rgba(255,255,255,0.8)",
    }}>
      <input type="checkbox" checked={completed} onChange={() => onToggle(id)} />

      <div style={{ display: "grid", gap: 6 }}>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <span style={{
            padding: "4px 8px",
            borderRadius: 999,
            background: categoryColors[category] || categoryColors.Inne,
            border: "1px solid rgba(0,0,0,0.08)",
            fontSize: 12,
          }}>
            {category}
          </span>

          <span style={{
            padding: "4px 8px",
            borderRadius: 999,
            background: "rgba(0,0,0,0.06)",
            border: "1px solid rgba(0,0,0,0.08)",
            fontSize: 12,
          }}>
            {prLabel}
          </span>
        </div>

        {isEditing ? (
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") save();
              if (e.key === "Escape") cancel();
            }}
            style={{ padding: 10, borderRadius: 10, border: "1px solid rgba(0,0,0,0.2)" }}
            autoFocus
          />
        ) : (
          <span style={{ textDecoration: completed ? "line-through" : "none", opacity: completed ? 0.6 : 1 }}>
            {title}
          </span>
        )}

        <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <small style={{ opacity: 0.7 }}>Priorytet</small>
          <select value={priority} onChange={(e) => onPriorityChange(id, e.target.value)}>
            <option value="high">Wysoki</option>
            <option value="medium">Średni</option>
            <option value="low">Niski</option>
          </select>
        </label>
      </div>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "end" }}>
        {isEditing ? (
          <>
            <button type="button" onClick={save}>Zapisz</button>
            <button type="button" onClick={cancel}>Anuluj</button>
          </>
        ) : (
          <>
            <button type="button" onClick={() => setIsEditing(true)}>Edytuj</button>
            <button type="button" onClick={() => onDelete(id)}>Usuń</button>
          </>
        )}
      </div>
    </li>
  );
}
