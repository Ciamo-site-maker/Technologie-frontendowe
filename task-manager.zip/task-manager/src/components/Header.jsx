import QuoteOfTheDay from "./QuoteOfTheDay";

export default function Header() {
  const today = new Date().toLocaleDateString("pl-PL", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <header style={{ display: "grid", gap: 12 }}>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <h1 style={{ margin: 0 }}>📋 Menedżer Zadań</h1>
        <div style={{ opacity: 0.8 }}>{today}</div>
      </div>
      <QuoteOfTheDay />
    </header>
  );
}
