import { useMemo, useState } from "react";

const CATEGORIES = ["Praca", "Dom", "Zakupy", "Inne"];

function validateTitle(title) {
  const t = title.trim();
  const errors = {};
  if (t.length === 0) errors.title = "Tytuł jest wymagany.";
  else if (t.length < 3) errors.title = "Minimum 3 znaki.";
  else if (t.length > 100) errors.title = "Maksimum 100 znaków.";
  return errors;
}

export default function TaskForm({ onAdd }) {
  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState("medium");
  const [category, setCategory] = useState(CATEGORIES[0]);

  const errors = useMemo(() => validateTitle(title), [title]);
  const isValid = Object.keys(errors).length === 0;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isValid) return;

    const newTask = {
      id: crypto?.randomUUID ? crypto.randomUUID() : String(Date.now()),
      title: title.trim(),
      completed: false,
      priority,
      category,
    };

    onAdd(newTask);
    setTitle("");
    setPriority("medium");
    setCategory(CATEGORIES[0]);
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: "grid", gap: 10 }}>
      <div style={{ display: "grid", gap: 6 }}>
        <label htmlFor="title">Tytuł zadania</label>
        <input
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Np. Zrobić zakupy…"
          style={{
            padding: 10,
            borderRadius: 10,
            border: errors.title ? "2px solid #cc0000" : "1px solid rgba(0,0,0,0.2)",
            outline: "none",
          }}
        />
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
          <small style={{ color: errors.title ? "#cc0000" : "rgba(0,0,0,0.6)" }}>
            {errors.title ? errors.title : "OK"}
          </small>
          <small style={{ opacity: 0.7 }}>{title.trim().length}/100</small>
        </div>
      </div>

      <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
        <label style={{ display: "grid", gap: 6 }}>
          Priorytet
          <select value={priority} onChange={(e) => setPriority(e.target.value)}>
            <option value="high">Wysoki</option>
            <option value="medium">Średni</option>
            <option value="low">Niski</option>
          </select>
        </label>

        <label style={{ display: "grid", gap: 6 }}>
          Kategoria
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </label>

        <button type="submit" disabled={!isValid} style={{ alignSelf: "end" }}>
          Dodaj zadanie
        </button>
      </div>
    </form>
  );
}
