export default function FilterButtons({ filter, onChange }) {
  const Btn = ({ value, children }) => {
    const active = filter === value;
    return (
      <button
        type="button"
        onClick={() => onChange(value)}
        style={{
          fontWeight: active ? 700 : 400,
          border: active ? "2px solid black" : "1px solid rgba(0,0,0,0.2)",
          padding: "8px 10px",
          borderRadius: 10,
          background: active ? "white" : "rgba(255,255,255,0.7)",
        }}
      >
        {children}
      </button>
    );
  };

  return (
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
      <Btn value="all">Wszystkie</Btn>
      <Btn value="active">Aktywne</Btn>
      <Btn value="completed">Ukończone</Btn>
    </div>
  );
}
