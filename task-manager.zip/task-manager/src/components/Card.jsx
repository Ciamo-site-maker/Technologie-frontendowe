export default function Card({ title, className = "", children }) {
  return (
    <section
      className={`card ${className}`.trim()}
      style={{
        background: "white",
        borderRadius: 16,
        padding: 16,
        boxShadow: "0 8px 20px rgba(0,0,0,0.08)",
      }}
    >
      {title ? <h2 style={{ marginTop: 0 }}>{title}</h2> : null}
      {children}
    </section>
  );
}
