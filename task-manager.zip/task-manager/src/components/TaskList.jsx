import TaskItem from "./TaskItem";

export default function TaskList({
  tasks,
  onToggle,
  onDelete,
  onPriorityChange,
  onUpdateTitle,
}) {
  if (tasks.length === 0) {
    return <p style={{ margin: 0, opacity: 0.8 }}>Brak zadań do wyświetlenia.</p>;
  }

  return (
    <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "grid", gap: 10 }}>
      {tasks.map((t) => (
        <TaskItem
          key={t.id}
          {...t}
          onToggle={onToggle}
          onDelete={onDelete}
          onPriorityChange={onPriorityChange}
          onUpdateTitle={onUpdateTitle}
        />
      ))}
    </ul>
  );
}
