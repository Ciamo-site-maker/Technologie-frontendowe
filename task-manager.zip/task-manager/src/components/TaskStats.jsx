export default function TaskStats({ tasks }) {
  const total = tasks.length;
  const done = tasks.filter((t) => t.completed).length;
  const left = total - done;
  const pct = total === 0 ? 0 : Math.round((done / total) * 100);

  return (
    <div style={{ display: "flex", gap: 16, flexWrap: "wrap", alignItems: "center", opacity: 0.9 }}>
      <span>Łącznie: <strong>{total}</strong></span>
      <span>Ukończone: <strong>{done}</strong></span>
      <span>Pozostałe: <strong>{left}</strong></span>
      <span>Postęp: <strong>{pct}%</strong></span>
    </div>
  );
}
